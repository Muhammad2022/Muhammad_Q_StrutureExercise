import UIKit

struct engine {
    var engineOne = ""
    var engineTwo = ""
    var engineThree = ""
    
    func allengine() -> String {
        return " Ihave three engines:" + "\n" + engineOne + " " + engineThree + " " + engineThree
    }
    

}
var onlyEngine = engine (engineOne: "V4", engineTwo:"V8", engineThree: "V6")

onlyEngine.allengine()

print(onlyEngine.allengine())
